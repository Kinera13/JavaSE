package team.mediasoft.course.java.se.db.exception;

public class ArticlesDataSourceException extends Exception {
    public ArticlesDataSourceException(String description) {
        super(description);
    }
}
