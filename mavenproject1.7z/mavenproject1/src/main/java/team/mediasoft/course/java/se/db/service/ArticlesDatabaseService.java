package team.mediasoft.course.java.se.db.service;

import team.mediasoft.course.java.se.db.entity.Articles;
import team.mediasoft.course.java.se.db.exception.DatabaseException;
import team.mediasoft.course.java.se.db.exception.ArticlesDataSourceException;
import team.mediasoft.course.java.se.db.facade.DatabaseFacade;
import team.mediasoft.course.java.se.db.facade.PostgresDatabaseFacade;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ArticlesDatabaseService implements ArticlesService {
    private final DatabaseFacade databaseFacade = new PostgresDatabaseFacade();
    private final String databaseLogin = "postgres";
    private final String databasePassword = "Gvynbleid";
    private final String tableName = "articles";
    private final String titleField = "title";
    private final String contentField = "content";

    @Override
    public List<Articles> getAllArticles() throws ArticlesDataSourceException {
        List<Articles> articleS = new ArrayList<>();
        try {
            this.databaseFacade.connect(this.databaseLogin, this.databasePassword);
            Connection connection = this.databaseFacade.getConnection();
            if(connection != null) {
                Statement statement = connection.createStatement();
                String sql = "select * from " + this.tableName;
                ResultSet resultSet = statement.executeQuery(sql);
                while(resultSet.next()) {
                    Articles articles = new Articles();
                    articles.setTitle(resultSet.getString(this.titleField));
                    articles.setContent(resultSet.getString(this.contentField));
                    articleS.add(articles);
                }

            }
        } catch (DatabaseException de) {
            throw new ArticlesDataSourceException(de.getMessage() + "Unable to get articles list from the database: ");
        } catch (SQLException sqle) {
            throw new ArticlesDataSourceException("Error while operating with the database statement");
        } finally {
            this.databaseFacade.disconnect();
        }

        return articleS;
    }

    @Override
    public Articles getArticlesByTitle(String title) throws ArticlesDataSourceException {
        Articles articles = null;
        try {
            this.databaseFacade.connect(this.databaseLogin, this.databasePassword);
            Connection connection = this.databaseFacade.getConnection();
            if(connection != null) {
                String sql = "select * from " + this.tableName + " where " + this.titleField + " = ?";
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                ResultSet resultSet = preparedStatement.executeQuery();
                while(resultSet.next()) {
                    articles = new Articles();
                    articles.setTitle(resultSet.getString(this.titleField));
                    articles.setContent(resultSet.getString(this.contentField));
                }

            }
        } catch (DatabaseException de) {
            throw new ArticlesDataSourceException("Unable to get person from the database: " + de.getMessage());
        } catch (SQLException sqle) {
            throw new ArticlesDataSourceException("Error while operating with the database statement");
        } finally {
            this.databaseFacade.disconnect();
        }

        return articles;
    }
}
