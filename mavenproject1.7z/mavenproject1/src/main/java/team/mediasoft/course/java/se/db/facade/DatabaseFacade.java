package team.mediasoft.course.java.se.db.facade;

import team.mediasoft.course.java.se.db.exception.DatabaseException;

import java.sql.Connection;

public interface DatabaseFacade {
    void connect(String login, String password) throws DatabaseException;
    Connection getConnection();
    void disconnect();
}
