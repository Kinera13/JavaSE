package team.mediasoft.course.java.se.db;

import team.mediasoft.course.java.se.db.exception.ArticlesDataSourceException;
import team.mediasoft.course.java.se.db.service.ArticlesDatabaseService;
import team.mediasoft.course.java.se.db.service.ArticlesService;

public class Runner {
    public static void main(String[] args) {
        ArticlesService articlesService = new ArticlesDatabaseService();

        try {
            System.out.println("All of the articles: ");
            articlesService.getAllArticles().forEach(System.out::println);

            System.out.println("");
            
        } catch (ArticlesDataSourceException pdse) {
             pdse.printStackTrace();
        }


    }
}
