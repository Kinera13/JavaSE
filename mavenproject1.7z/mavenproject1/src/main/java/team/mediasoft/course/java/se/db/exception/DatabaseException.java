package team.mediasoft.course.java.se.db.exception;

public class DatabaseException extends Exception {
    public DatabaseException(String description) {
        super(description);
    }
}
