package team.mediasoft.course.java.se.db.entity;

public class Articles {
    private String title;
    private String content;

    @Override
    public String toString() {
        return this.getTitle() + "\n " + "\n" + this.getContent();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
