package team.mediasoft.course.java.se.db.service;

import team.mediasoft.course.java.se.db.entity.Articles;
import team.mediasoft.course.java.se.db.exception.ArticlesDataSourceException;

import java.util.List;

public interface ArticlesService {
    List<Articles> getAllArticles() throws ArticlesDataSourceException;
    Articles getArticlesByTitle(String title) throws ArticlesDataSourceException;
}
