package team.mediasoft.course.java.se.db;

import team.mediasoft.course.java.se.db.exception.PersonDataSourceException;
import team.mediasoft.course.java.se.db.service.PersonDatabaseService;
import team.mediasoft.course.java.se.db.service.PersonService;

public class Runner {
    public static void main(String[] args) {
        PersonService personService = new PersonDatabaseService();

        try {
            System.out.println("All of the persons: ");
            personService.getAllPersons().forEach(System.out::println);

            System.out.println("");
            System.out.println("Person with the ID = 2:");
            System.out.println(personService.getPersonByID(2));
        } catch (PersonDataSourceException pdse) {
            pdse.printStackTrace();
        }


    }
}
